此为修改psp游戏启动文件工具
pbp-unpacker只能在全英目录下运行
其中pbp-unpacker本人未找到作者
kautismSFOEditor的原发布地为GitHub见下方链接
https://github.com/darkautism/KautismSFOEditor